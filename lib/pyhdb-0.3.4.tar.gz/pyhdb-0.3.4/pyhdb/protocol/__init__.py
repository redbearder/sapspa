# The following import is required to register the 'cesu8' codec in Python:
import pyhdb.cesu8
